#!/usr/bin/env perl

# This script will be called after installing Perl-Modules.  It validates
# that the paths added to PERL5LIB exist in the installed filesystem,
# and prints a warning to the post-install/README file if a path
# is non-existent

my $VDT_LOCATION = $ENV{VDT_LOCATION};
my $have_logged = 0;

# The post-install readme should be in this variable...
my $README = $ENV{VDT_POSTINSTALL_README};
if(! -e $README) {
    # ... but if it's not, this should be the standard location
    if(-e "$VDT_LOCATION/post-install/README") {
	$README = "$VDT_LOCATION/post-install/README";
    }
    else {
	$README = "";
    }
}

# Print to the README if we can, otherwise just keep using STDOUT
if($README && open(OUT, ">>", $README)) {
    select(OUT);
}

# Run perl-setup.pl, which generates the paths to add to PERL5LIB
my @out;
if(-e "$VDT_LOCATION/perl/perl-setup.pl") {
    @out = `$VDT_LOCATION/perl/perl-setup.pl`;
}
else {
    log_message("Error: validate_perl_lib_paths.pl cannot find perl-setup.pl in $VDT_LOCATION/perl\n");
    exit(1);
}

# Validate that each path exists.
my $bad_paths = 0;
foreach my $line (@out) {
    chomp($line);
    foreach my $path (split(":", $line)) {
	if(! -d $path) {
	    $bad_paths++;
	    log_message("Warning: Non-existent path '$path' is being added to PERL5LIB.\n");
	}
    }
}

finish_log();

sub log_message
{
    if ($have_logged == 0) {
        # Just a header for the post-install/README file
        print "\n===== Validating PERL5LIB paths =====\n";
        $have_logged = 1;
    }
    print $_[0];
    return;
}

sub finish_log 
{
    if ($have_logged) {
        print "\n\n";
    }
    return;
}
