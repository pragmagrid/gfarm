PERL5LIB=`$VDT_LOCATION/perl/perl-setup.pl`
export PERL5LIB
